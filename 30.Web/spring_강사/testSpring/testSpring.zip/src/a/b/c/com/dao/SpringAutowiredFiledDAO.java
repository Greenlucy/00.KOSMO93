package a.b.c.com.dao;

import java.util.List;

import a.b.c.com.vo.FormDataVO;

public interface SpringAutowiredFiledDAO {

	public List<FormDataVO> autowiredTest(FormDataVO fvo);
}
