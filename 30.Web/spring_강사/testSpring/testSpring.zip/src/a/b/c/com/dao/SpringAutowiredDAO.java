package a.b.c.com.dao;

import java.util.List;

import a.b.c.com.vo.FormDataVO;

public interface SpringAutowiredDAO {

	public List<FormDataVO> autowiredTest(FormDataVO fvo);
}
