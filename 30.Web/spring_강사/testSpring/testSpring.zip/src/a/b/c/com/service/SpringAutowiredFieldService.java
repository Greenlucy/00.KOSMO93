package a.b.c.com.service;

import java.util.List;

import a.b.c.com.vo.FormDataVO;

public interface SpringAutowiredFieldService {

	public List<FormDataVO> autowiredTest(FormDataVO fvo);
}
