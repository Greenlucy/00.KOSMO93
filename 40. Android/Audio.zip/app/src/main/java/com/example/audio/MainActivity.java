package com.example.audio;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    // 미디어 플레이어 객체 생성
    MediaPlayer mp = new MediaPlayer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mp = MediaPlayer.create(this, R.raw.hare);      // 미디어 플레이어에 오디오 파일 설정
        mp.setLooping(false);               // 노래 재생 비반복
        mp.start();                         // 노래 재생 시작
    }

    // 액티비티 종료 시 호출되는 메소드
    protected void onDestroy() {
        // 노래가 재생 중이면 중지하고 미디어 플레이어 자원을 해제
        if (mp.isPlaying()) {
            mp.stop();
            mp.release();
        }
        super.onDestroy();
    }
}